export interface IMenuItemsRequest {
  location_id: string | null | undefined;
}