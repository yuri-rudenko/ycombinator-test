export interface ICategoryRequest {
  location_id?: string | null;
}