export enum ERequestRoutes {
  LOCATIONS = "locations",
  CATALOG = "catalog",
  CATEGORIES = "catalog/categories",
}
